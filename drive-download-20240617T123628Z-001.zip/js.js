
let totalMessages = 0,
  messagesLimit = 0,
  nickColor = "user",
  removeSelector,
  addition,
  customNickColor,
  channelName,
  provider;
let selfColor, modColor, regularColor, subColor;

let animationIn = "bounceIn";
let animationOut = "bounceOut";
let hideAfter = 60;
let hideCommands = "no";
let ignoredUsers = [];


let count = 0;

document.addEventListener("keypress", function (event) {
  if (event.keyCode == 32) {
    test();
  }
});



function test() {

  setTimeout(() => {
    let wname = "Testing"+count;
    let type = "follower-latest"
    let amount = 123;
    doNotif(type, wname, amount)
  }, 1000);

  setTimeout(() => {
    count++;
    wname = "Testing";
    type = "subscriber-latest"
    amount = 123;
    doNotif(type, wname, amount)
  }, 2500);

  setTimeout(() => {
    wname = "Testing";
    type = "cheer-latest"
    amount = 123;
    doNotif(type, wname, amount)
  }, 2500);

  
  setTimeout(() => {
    wname = "Testing";
    type = "raid-latest"
    amount = 123;
    doNotif(type, wname, amount)
  }, 4000);
  

  setTimeout(() => {
    console.log("Test");
  let username = "Testing";
  let badges = ` `;
  let message = "This Test MSG!"
  let action = true;
  let userId = 123;
  let listBadges = [
  ];
  addMessage(
    username,
    badges,
    message,
    action,
    userId,
    userId,
    listBadges
  );


  username = "Testing Mod";
  badges = `<img alt="" src="https://yt3.ggpht.com/1sPg61lxt4x_8vqd8aFWEt41VmbYhtf999GqhVPD0PpJucqB_4KXjYMWG_h_wmYfpZY54IT_4g=s16-c-k" class="badge"> `;
  message = "This Test MSG! Mod"
  action = true;
  userId = 123;
  listBadges = [
    "moderator"
  ];
  addMessage(
    username,
    badges,
    message,
    action,
    userId,
    userId,
    listBadges
  );
  }, 1000);
  
  setTimeout(() => {
    username = "Testing broadcaster";
    badges = `<img alt="" src="https://yt3.ggpht.com/1sPg61lxt4x_8vqd8aFWEt41VmbYhtf999GqhVPD0PpJucqB_4KXjYMWG_h_wmYfpZY54IT_4g=s16-c-k" class="badge"> `;
    message = "This Test MSG! broadcaster"
    action = true;
    userId = 123;
    listBadges = [
      "broadcaster"
    ];
    addMessage(
      username,
      badges,
      message,
      action,
      userId,
      userId,
      listBadges
    );
  
    username = "Testing subscriber";
    badges = `<img alt="" src="https://yt3.ggpht.com/1sPg61lxt4x_8vqd8aFWEt41VmbYhtf999GqhVPD0PpJucqB_4KXjYMWG_h_wmYfpZY54IT_4g=s16-c-k" class="badge"> `;
    message = "This Test MSG! subscriber"
    action = true;
    userId = 123;
    listBadges = [
      "subscriber"
    ];
    addMessage(
      username,
      badges,
      message,
      action,
      userId,
      userId,
      listBadges
    );
  }, 6000);

  

  // username = "Testing artist";
  // badges = `<img alt="" src="https://yt3.ggpht.com/1sPg61lxt4x_8vqd8aFWEt41VmbYhtf999GqhVPD0PpJucqB_4KXjYMWG_h_wmYfpZY54IT_4g=s16-c-k" class="badge"> `;
  // message = "This Test MSG! artist"
  // action = true;
  // userId = 123;
  // listBadges = [
  //   "artist"
  // ];
  // addMessage(
  //   username,
  //   badges,
  //   message,
  //   action,
  //   userId,
  //   userId,
  //   listBadges
  // );

  username = "Testing vip";
  badges = `<img alt="" src="https://yt3.ggpht.com/1sPg61lxt4x_8vqd8aFWEt41VmbYhtf999GqhVPD0PpJucqB_4KXjYMWG_h_wmYfpZY54IT_4g=s16-c-k" class="badge"> `;
  message = "This Test MSG! vip"
  action = true;
  userId = 123;
  listBadges = [
    "vip"
  ];
  addMessage(
    username,
    badges,
    message,
    action,
    userId,
    userId,
    listBadges
  );

}


window.addEventListener("onEventReceived", function (obj) {
  if (obj.detail.event.listener === "widget-button") {
    if (obj.detail.event.field === "testMessage") {
      let emulatedDef = defaultEvent();
      let emulatedMod = moderatorEvent();
      let emulatedOwn = ownerEvent();
      let emulatedSub = subscriberEvent();
      let emulatedVip = vipEvent();
      let emulatedArtist = artistEvent();
      window.dispatchEvent(emulatedDef);
      window.dispatchEvent(emulatedMod);
      window.dispatchEvent(emulatedOwn);
      window.dispatchEvent(emulatedSub);
      window.dispatchEvent(emulatedArtist);
      window.dispatchEvent(emulatedVip);
    }
    return;
  }
  if (obj.detail.listener === "delete-message") {
    const msgId = obj.detail.event.msgId;
    $(`.message-row[data-msgid=${msgId}]`).remove();
    return;
  } else if (obj.detail.listener === "delete-messages") {
    const sender = obj.detail.event.userId;
    $(`.message-row[data-sender=${sender}]`).remove();
    return;
  }
  console.log("=> " + obj.detail.listener)
  if (
    obj.detail.listener == "follower-latest" ||
    obj.detail.listener == "subscriber-latest" ||
    obj.detail.listener == "raid-latest" ||
    obj.detail.listener == "cheer-latest"
  ) {
    let data = obj.detail;
    console.log(data);
    let name = obj.detail.event.name;
    let amount = obj.detail.event.amount;
    let type = obj.detail.listener;
    doNotif(type, name, amount);
    return;
  }

  if (obj.detail.listener !== "message") return;
  let data = obj.detail.event.data;
  if (data.text.startsWith("!") && hideCommands === "yes") return;
  if (ignoredUsers.indexOf(data.nick) !== -1) return;
  let message = attachEmotes(data);
  let badges = "",
    badge;
  let listBadge = [];

  if (provider === "mixer") {
    data.badges.push({ url: data.avatar });
  }
  for (let i = 0; i < data.badges.length; i++) {
    badge = data.badges[i];
    listBadge.push(badge.type);
    badges += `<img alt="" src="${badge.url}" class="badge"> `;
  }

  let username = data.displayName;
  addMessage(
    username,
    badges,
    message,
    data.isAction,
    data.userId,
    data.msgId,
    listBadge
  );
});


function moderatorEvent() {
  return new CustomEvent("onEventReceived", {
    detail: {
      listener: "message",
      event: {
        service: "twitch",
        data: {
          time: Date.now(),
          tags: {
            "badge-info": "",
            badges: "moderator/1,partner/1",
            color: "#5B99FF",
            "display-name": "StreamElements",
            emotes: "25:46-50",
            flags: "",
            id: "43285909-412c-4eee-b80d-89f72ba53142",
            mod: "1",
            "room-id": "85827806",
            subscriber: "0",
            "tmi-sent-ts": "1579444549265",
            turbo: "0",
            "user-id": "100135110",
            "user-type": "mod",
          },
          nick: channelName,
          userId: "100135110",
          displayName: channelName,
          displayColor: "#5B99FF",
          badges: [
            {
              type: "moderator",
              version: "1",
              url: "https://static-cdn.jtvnw.net/badges/v1/3267646d-33f0-4b17-b3df-f923a41db1d0/3",
              description: "Moderator",
            },
            {
              type: "partner",
              version: "1",
              url: "https://static-cdn.jtvnw.net/badges/v1/d12a2e27-16f6-41d0-ab77-b780518f00a3/3",
              description: "Verified",
            },
          ],
          channel: channelName,
          text: "Howdy! My name is Bill and I am here to serve Kappa",
          isAction: !1,
          emotes: [
            {
              type: "twitch",
              name: "Kappa",
              id: "25",
              gif: !1,
              urls: {
                1: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                2: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                4: "https://static-cdn.jtvnw.net/emoticons/v1/25/3.0",
              },
              start: 46,
              end: 50,
            },
          ],
          msgId: "43285909-412c-4eee-b80d-89f72ba53142",
        },
        renderedText:
          'Howdy! My name is Bill and I am here to serve <img src="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0" srcset="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 1x, https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 2x, https://static-cdn.jtvnw.net/emoticons/v1/25/3.0 4x" title="Kappa" class="emote">',
      },
    },
  });
}

function ownerEvent() {
  return new CustomEvent("onEventReceived", {
    detail: {
      listener: "message",
      event: {
        service: "twitch",
        data: {
          time: Date.now(),
          tags: {
            "badge-info": "",
            badges: "broadcaster/1",
            color: "#5B99FF",
            "display-name": "StreamElements",
            emotes: "25:46-50",
            flags: "",
            id: "43285909-412c-4eee-b80d-89f72ba53142",
            mod: "1",
            "room-id": "85827806",
            subscriber: "0",
            "tmi-sent-ts": "1579444549265",
            turbo: "0",
            "user-id": "100135110",
            "user-type": "",
          },
          nick: channelName,
          userId: "100135110",
          displayName: channelName,
          displayColor: "#5B99FF",
          badges: [
            {
              type: "broadcaster",
              version: "1",
              url: "https://static-cdn.jtvnw.net/badges/v1/5527c58c-fb7d-422d-b71b-f309dcb85cc1/3",
              description: "broadcaster",
            },
          ],
          channel: channelName,
          text: "EIYOWW Test Broadcaster!!",
          isAction: !1,
          emotes: [
            {
              type: "twitch",
              name: "Kappa",
              id: "25",
              gif: !1,
              urls: {
                1: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                2: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                4: "https://static-cdn.jtvnw.net/emoticons/v1/25/3.0",
              },
              start: 46,
              end: 50,
            },
          ],
          msgId: "43285909-412c-4eee-b80d-89f72ba53142",
        },
        renderedText:
          'Howdy! My name is Bill and I am here to serve <img src="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0" srcset="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 1x, https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 2x, https://static-cdn.jtvnw.net/emoticons/v1/25/3.0 4x" title="Kappa" class="emote">',
      },
    },
  });
}

function subscriberEvent() {
  return new CustomEvent("onEventReceived", {
    detail: {
      listener: "message",
      event: {
        service: "twitch",
        data: {
          time: Date.now(),
          tags: {
            "badge-info": "",
            badges: "subscriber/1",
            color: "#5B99FF",
            "display-name": "StreamElements",
            emotes: "25:46-50",
            flags: "",
            id: "43285909-412c-4eee-b80d-89f72ba53142",
            mod: "1",
            "room-id": "85827806",
            subscriber: "0",
            "tmi-sent-ts": "1579444549265",
            turbo: "0",
            "user-id": "100135110",
            "user-type": "",
          },
          nick: channelName,
          userId: "100135110",
          displayName:
            "Your Fan is currently testing long name, this is for testing purposes only :>>> Fan!",
          displayColor: "#5B99FF",
          badges: [
            {
              type: "subscriber",
              version: "1",
              url: "https://static-cdn.jtvnw.net/badges/v1/181d384e-16a9-4a9a-9853-2c87479b4f2b/1",
              description: "subscriber",
            },
          ],
          channel: channelName,
          text: "EIYOWW this fan is currently testing long message Test Subscriber!!",
          isAction: !1,
          emotes: [
            {
              type: "twitch",
              name: "Kappa",
              id: "25",
              gif: !1,
              urls: {
                1: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                2: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                4: "https://static-cdn.jtvnw.net/emoticons/v1/25/3.0",
              },
              start: 46,
              end: 50,
            },
          ],
          msgId: "43285909-412c-4eee-b80d-89f72ba53142",
        },
        renderedText:
          'Howdy! My name is Bill and I am here to serve <img src="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0" srcset="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 1x, https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 2x, https://static-cdn.jtvnw.net/emoticons/v1/25/3.0 4x" title="Kappa" class="emote">',
      },
    },
  });
}

function artistEvent() {
  return new CustomEvent("onEventReceived", {
    detail: {
      listener: "message",
      event: {
        service: "twitch",
        data: {
          time: Date.now(),
          tags: {
            "badge-info": "",
            badges: "artist/1",
            color: "#5B99FF",
            "display-name": "StreamElements",
            emotes: "25:46-50",
            flags: "",
            id: "43285909-412c-4eee-b80d-89f72ba53142",
            mod: "1",
            "room-id": "85827806",
            subscriber: "0",
            "tmi-sent-ts": "1579444549265",
            turbo: "0",
            "user-id": "100135110",
            "user-type": "",
          },
          nick: channelName,
          userId: "100135110",
          displayName: "Artist!",
          displayColor: "#5B99FF",
          badges: [
            {
              type: "artist",
              version: "1",
              url: "https://assets.help.twitch.tv/article/img/000002399-05.png",
              description: "subscriber",
            },
          ],
          channel: channelName,
          text: "Artist hehe",
          isAction: !1,
          emotes: [
            {
              type: "twitch",
              name: "Kappa",
              id: "25",
              gif: !1,
              urls: {
                1: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                2: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                4: "https://static-cdn.jtvnw.net/emoticons/v1/25/3.0",
              },
              start: 46,
              end: 50,
            },
          ],
          msgId: "43285909-412c-4eee-b80d-89f72ba53142",
        },
        renderedText:
          'Howdy! My name is Bill and I am here to serve <img src="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0" srcset="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 1x, https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 2x, https://static-cdn.jtvnw.net/emoticons/v1/25/3.0 4x" title="Kappa" class="emote">',
      },
    },
  });
}

function vipEvent() {
  return new CustomEvent("onEventReceived", {
    detail: {
      listener: "message",
      event: {
        service: "twitch",
        data: {
          time: Date.now(),
          tags: {
            "badge-info": "",
            badges: "vip/1",
            color: "#5B99FF",
            "display-name": "StreamElements",
            emotes: "25:46-50",
            flags: "",
            id: "43285909-412c-4eee-b80d-89f72ba53142",
            mod: "1",
            "room-id": "85827806",
            subscriber: "0",
            "tmi-sent-ts": "1579444549265",
            turbo: "0",
            "user-id": "100135110",
            "user-type": "",
          },
          nick: channelName,
          userId: "100135110",
          displayName: "vip!",
          displayColor: "#5B99FF",
          badges: [
            {
              type: "vip",
              version: "1",
              url: "https://static-cdn.jtvnw.net/badges/v1/b817aba4-fad8-49e2-b88a-7cc744dfa6ec/3",
              description: "subscriber",
            },
          ],
          channel: channelName,
          text: "vip hehe",
          isAction: !1,
          emotes: [
            {
              type: "twitch",
              name: "Kappa",
              id: "25",
              gif: !1,
              urls: {
                1: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                2: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                4: "https://static-cdn.jtvnw.net/emoticons/v1/25/3.0",
              },
              start: 46,
              end: 50,
            },
          ],
          msgId: "43285909-412c-4eee-b80d-89f72ba53142",
        },
        renderedText:
          'Howdy! My name is Bill and I am here to serve <img src="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0" srcset="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 1x, https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 2x, https://static-cdn.jtvnw.net/emoticons/v1/25/3.0 4x" title="Kappa" class="emote">',
      },
    },
  });
}

function defaultEvent() {
  return new CustomEvent("onEventReceived", {
    detail: {
      listener: "message",
      event: {
        service: "twitch",
        data: {
          time: Date.now(),
          tags: {
            "badge-info": "",
            badges: "",
            color: "#5B99FF",
            "display-name": "StreamElements",
            emotes: "25:46-50",
            flags: "",
            id: "43285909-412c-4eee-b80d-89f72ba53142",
            mod: "1",
            "room-id": "85827806",
            subscriber: "0",
            "tmi-sent-ts": "1579444549265",
            turbo: "0",
            "user-id": "100135110",
            "user-type": "",
          },
          nick: channelName,
          userId: "100135110",
          displayName: channelName,
          displayColor: "#5B99FF",
          badges: [],
          channel: channelName,
          text: "NORMALL GENGGSS!!",
          isAction: !1,
          emotes: [
            {
              type: "twitch",
              name: "Kappa",
              id: "25",
              gif: !1,
              urls: {
                1: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                2: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                4: "https://static-cdn.jtvnw.net/emoticons/v1/25/3.0",
              },
              start: 46,
              end: 50,
            },
          ],
          msgId: "43285909-412c-4eee-b80d-89f72ba53142",
        },
        renderedText:
          'Howdy! My name is Bill and I am here to serve <img src="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0" srcset="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 1x, https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 2x, https://static-cdn.jtvnw.net/emoticons/v1/25/3.0 4x" title="Kappa" class="emote">',
      },
    },
  });
}

window.addEventListener("onWidgetLoad", function (obj) {
  const fieldData = obj.detail.fieldData;
  hideAfter = fieldData.hideAfter;
  messagesLimit = fieldData.messagesLimit;
  hideCommands = fieldData.hideCommands;

  selfColor = fieldData.selfColor;
  modColor = fieldData.modColor;
  regularColor = fieldData.regularColor;
  subColor = fieldData.subColor;

  channelName = obj.detail.channel.username;

  fetch(
    "https://api.streamelements.com/kappa/v2/channels/" +
    obj.detail.channel.id +
    "/"
  )
    .then((response) => response.json())
    .then((profile) => {
      provider = profile.provider;
    });
  if (fieldData.alignMessages === "block") {
    addition = "prepend";
    removeSelector = ".message-row:nth-child(n+" + (messagesLimit + 1) + ")";
  } else {
    addition = "append";
    removeSelector =
      ".message-row:nth-last-child(n+" + (messagesLimit + 1) + ")";
  }

  ignoredUsers = fieldData.ignoredUsers
    .toLowerCase()
    .replace(" ", "")
    .split(",");
});

function attachEmotes(message) {
  let text = html_encode(message.text);
  let data = message.emotes;
  if (typeof message.attachment !== "undefined") {
    if (typeof message.attachment.media !== "undefined") {
      if (typeof message.attachment.media.image !== "undefined") {
        text = `${message.text}<img src="${message.attachment.media.image.src}">`;
      }
    }
  }
  return text.replace(/([^\s]*)/gi, function (m, key) {
    let result = data.filter((emote) => {
      return html_encode(emote.name) === key;
    });
    if (typeof result[0] !== "undefined") {
      let url = result[0]["urls"][1];
      if (provider === "twitch") {
        return `<img class="emote" " src="${url}"/>`;
      } else {
        if (typeof result[0].coords === "undefined") {
          result[0].coords = { x: 0, y: 0 };
        }
        let x = parseInt(result[0].coords.x);
        let y = parseInt(result[0].coords.y);

        let width = "{emoteSize}px";
        let height = "auto";

        if (provider === "mixer") {
          console.log(result[0]);
          if (result[0].coords.width) {
            width = `${result[0].coords.width}px`;
          }
          if (result[0].coords.height) {
            height = `${result[0].coords.height}px`;
          }
        }
        return `<div class="emote" style="width: ${width}; height:${height}; display: inline-block; background-image: url(${url}); background-position: -${x}px -${y}px;"></div>`;
      }
    } else return key;
  });
}

function html_encode(e) {
  return e.replace(/[<>"^]/g, function (e) {
    return "&#" + e.charCodeAt(0) + ";";
  });
}

function getRole(listBadge) {
  if (listBadge.includes("moderator")) {
    return "mod";
  } else if (listBadge.includes("broadcaster")) {
    return "broadcast";
  } else if (listBadge.includes("vip")) {
    return "vip";
  } else if (listBadge.includes("subscriber")) {
    return "subs";
  } else if (listBadge.includes("artist")) {
    return "artist";
  } else {
    return "regular";
  }
}

function doNotif(type, name, amount) {
  totalMessages += 1;
  let element = "";
  if (type == "follower-latest") {
    element = $.parseHTML(`
    <div class="body-alert">
    <div id="section-alert">
        <div id="crab-alert">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1135613865779011704/download.png"
                alt="" srcset="">
        </div>
        <div id="wave-2-alert">
            <img style="max-width: 100px; max-height: 100px;"
                src="https://cdn.discordapp.com/attachments/1047757132294000691/1164919572638470235/Kiri_png.png?ex=6544f6e5&is=653281e5&hm=688c03ce3350ef70a4b39c2fba9dd20156929683919aaa45a234d7e430cb7292&"
                alt="" srcset="">
        </div>
        <div id="container-alert">
            <div id="rotator-alert" class="follower-alert">
                <div id="username-alert">
                    <div id="name-alert">${name}</div>
                    <div id="logo-alert">
                        <img src="https://static-cdn.jtvnw.net/badges/v1/8627f58b-3f55-44cf-b0c4-33758b4a249b/2"
                            alt="">
                    </div>
                </div>
                <div id="text-alert">
                     is following!
                </div>
            </div>
        </div>
        <div id="wave-alert">
            <img style="max-width: 100px; max-height: 100px;"
                src="https://cdn.discordapp.com/attachments/1047757132294000691/1164919572944662589/Kanan_png.png?ex=6544f6e5&is=653281e5&hm=c5fafd7723aed523811dc7f737374e2e012ca646028570f112e1470b289e424b&"
                alt="" srcset="">
        </div>
    </div>
</div>
           `);
  }
  else if (type == "subscriber-latest") {
    element = $.parseHTML(`
    <div class="body-alert">
    <div id="section-alert">
        <div id="crab-alert">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1135613865779011704/download.png"
                alt="" srcset="">
        </div>
        <div id="wave-2-alert">
            <img style="max-width: 100px; max-height: 100px;"
                src="https://cdn.discordapp.com/attachments/1047757132294000691/1164919572638470235/Kiri_png.png?ex=6544f6e5&is=653281e5&hm=688c03ce3350ef70a4b39c2fba9dd20156929683919aaa45a234d7e430cb7292&"
                alt="" srcset="">
        </div>
        <div id="container-alert">
            <div id="rotator-alert" class="subscriber-alert">
                <div id="username-alert">
                    <div id="name-alert">${name}</div>
                    <div id="logo-alert">
                        <img src="https://static-cdn.jtvnw.net/badges/v1/8627f58b-3f55-44cf-b0c4-33758b4a249b/2"
                            alt="">
                    </div>
                </div>
                <div id="text-alert">
                     is Subscribe for ${amount} months!
                </div>
            </div>
        </div>
        <div id="wave-alert">
            <img style="max-width: 100px; max-height: 100px;"
                src="https://cdn.discordapp.com/attachments/1047757132294000691/1164919572944662589/Kanan_png.png?ex=6544f6e5&is=653281e5&hm=c5fafd7723aed523811dc7f737374e2e012ca646028570f112e1470b289e424b&"
                alt="" srcset="">
        </div>
    </div>
</div>
           `);
  }
  else if (type == "cheer-latest") {
    element = $.parseHTML(`
    <div class="body-alert">
    <div id="section-alert">
        <div id="crab-alert">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1135613865779011704/download.png"
                alt="" srcset="">
        </div>
        <div id="wave-2-alert">
            <img style="max-width: 100px; max-height: 100px;"
                src="https://cdn.discordapp.com/attachments/1047757132294000691/1164919572638470235/Kiri_png.png?ex=6544f6e5&is=653281e5&hm=688c03ce3350ef70a4b39c2fba9dd20156929683919aaa45a234d7e430cb7292&"
                alt="" srcset="">
        </div>
        <div id="container-alert">
            <div id="rotator-alert" class="cheer-alert">
                <div id="username-alert">
                    <div id="name-alert">${name}</div>
                    <div id="logo-alert">
                        <img src="https://static-cdn.jtvnw.net/badges/v1/8627f58b-3f55-44cf-b0c4-33758b4a249b/2"
                            alt="">
                    </div>
                </div>
                <div id="text-alert">
                     is Redeemed for ${amount} bits!
                </div>
            </div>
        </div>
        <div id="wave-alert">
            <img style="max-width: 100px; max-height: 100px;"
                src="https://cdn.discordapp.com/attachments/1047757132294000691/1164919572944662589/Kanan_png.png?ex=6544f6e5&is=653281e5&hm=c5fafd7723aed523811dc7f737374e2e012ca646028570f112e1470b289e424b&"
                alt="" srcset="">
        </div>
    </div>
</div>
           `);
  }

  else if (type == "raid-latest") {
    element = $.parseHTML(`
    <div class="body-alert">
    <div id="section-alert">
        <div id="crab-alert">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1135613865779011704/download.png"
                alt="" srcset="">
        </div>
        <div id="wave-2-alert">
            <img style="max-width: 100px; max-height: 100px;"
                src="https://cdn.discordapp.com/attachments/1047757132294000691/1164919572638470235/Kiri_png.png?ex=6544f6e5&is=653281e5&hm=688c03ce3350ef70a4b39c2fba9dd20156929683919aaa45a234d7e430cb7292&"
                alt="" srcset="">
        </div>
        <div id="container-alert">
            <div id="rotator-alert" class="raid-alert">
                <div id="username-alert">
                    <div id="name-alert">${name}</div>
                    <div id="logo-alert">
                        <img src="https://static-cdn.jtvnw.net/badges/v1/8627f58b-3f55-44cf-b0c4-33758b4a249b/2"
                            alt="">
                    </div>
                </div>
                <div id="text-alert">
                     ${name} and ${amount} others is come to raid!
                </div>
            </div>
        </div>
        <div id="wave-alert">
            <img style="max-width: 100px; max-height: 100px;"
                src="https://cdn.discordapp.com/attachments/1047757132294000691/1164919572944662589/Kanan_png.png?ex=6544f6e5&is=653281e5&hm=c5fafd7723aed523811dc7f737374e2e012ca646028570f112e1470b289e424b&"
                alt="" srcset="">
        </div>
    </div>
</div>
           `);
  }

  if (addition === "append") {
    if (hideAfter !== 999) {
      $(element)
        .appendTo(".main-container")
        .delay(hideAfter * 1000)
        .queue(function () {
          $(this)
            .removeClass(animationIn)
            .addClass(animationOut)
            .delay(1000)
            .queue(function () {
              $(this).remove();
            })
            .dequeue();
        });
    } else {
      $(element).appendTo(".main-container");
    }
  } else {
    if (hideAfter !== 999) {
      $(element)
        .appendTo(".main-container")
        .delay(hideAfter * 1000)
        .queue(function () {
          $(this)
            .removeClass(animationIn)
            .addClass(animationOut)
            .delay(1000)
            .queue(function () {
              $(this).remove();
            })
            .dequeue();
        });
    } else {
      $(element).appendTo(".main-container");
    }
  }

  if (totalMessages > messagesLimit) {
    removeRow();
  }

}

function addMessage(
  username,
  badges,
  message,
  isAction,
  uid,
  msgId,
  listBadge
) {
  totalMessages += 1;
  let actionClass = "";
  if (isAction) {
    actionClass = "action";
  }
  role = getRole(listBadge);
  console.log(role);
  let element = "";
  if (role == "regular") {
    element = $.parseHTML(`
            <div data-sender="${uid}" data-msgid="${msgId}" id="section">
                
                <div id="ear">
                <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765824646459472/Reg_Head.svg" alt="">
                </div>
                <div id="username" class="username-regular">
                <div id="logo">
                    <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1166375219062112296/NORMAL.png?ex=654a4292&is=6537cd92&hm=ba27d029609bcb9b5bc3db3c76682765dbcb91eab460b585ab37524fd2513f7a&" alt="">
                    </div>
                    <div id="name" class="regular-name">${username}</div>
                    
                    </div>
                <div id="container">
                <div id="crab">
                <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765824285753414/Reg_Chat_atas_kanan.svg?ex=653d210f&is=652aac0f&hm=84a65040765179afd1026245f2b2f78c7c2a5bc409a49c9fbb5172e91b724885&" alt=""
                    srcset="">
                </div>
                <div id="bintang-kiri">
                    <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765837837553684/Star_chat.svg?ex=653d2112&is=652aac12&hm=ad048aa3ad02fce65945f4599c92f586e014696d23c8cd1cabe9b4ac253a2d43&" alt="">
                </div>
                <div id="rotator" class="regular">
                    
                    <div id="text">
                    ${message}
                    </div>
                </div>
                <div id="bintang-kanan">
                    <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1163155306851864696/Asset_1.png?ex=653e8bcb&is=652c16cb&hm=016b92b9dd406679a42a757ccf1d677720c5d4c8a8e62b3c3c3157c3dc447d2a&" alt="">
                </div>
                </div>
                <div id="child-left">
        <img style="max-width: 100px; max-height: 100px;" src="https://cdn.discordapp.com/attachments/1047757132294000691/1163177331905532096/Ujung_kiri.png?ex=653ea04e&is=652c2b4e&hm=9cba56c016453abd6757943cfae45e3c9783daa96bd1a91e254f648393731fa2&" alt="" srcset="">
        </div>
                <div id="wave">
                <img style="max-width: 100px; max-height: 100px;"
                    src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765821685285055/Reg_Kanan_Bawah.svg?ex=653d210f&is=652aac0f&hm=06abce25ccfb514abd19e74f12cc1990323dccc09afecdcdbffbe83167ac71a4&" alt=""
                    srcset="">
                </div>
            </div>
            `);
  } else if (role == "vip") {
    element = $.parseHTML(`
    <div data-sender="${uid}" data-msgid="${msgId}" id="section">
        
        <div id="ear">
                <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765837137096728/VIP_Head.svg" alt="">
        </div>
        <div id="username" class="username-vip" >
        <div id="logo">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1166375221796798615/VIP.png?ex=654a4293&is=6537cd93&hm=93a42014729dc645c5b4c5908a17de35ada2c2d013ce5025cd05ee74fa9aab3f&" alt="">
            </div>
            <div id="name" class="vip-name">${username}</div>
            
            </div>
        <div id="container">
        <div id="crab">
        <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765839741763601/VIP_Chat_atas_kanan.svg?ex=653d2113&is=652aac13&hm=a6469a1131e184cf05c81505919e47642b86c0b1486cc247109b29b7c8b22eff&" alt=""
            srcset="">
        </div>
        <div id="bintang-kiri">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765837837553684/Star_chat.svg?ex=653d2112&is=652aac12&hm=ad048aa3ad02fce65945f4599c92f586e014696d23c8cd1cabe9b4ac253a2d43&" alt="">
        </div>
        <div id="rotator" class="vip">
            
            <div id="text">
            ${message}
            </div>
        </div>
        <div id="bintang-kanan">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1163155306851864696/Asset_1.png?ex=653e8bcb&is=652c16cb&hm=016b92b9dd406679a42a757ccf1d677720c5d4c8a8e62b3c3c3157c3dc447d2a&" alt="">
        </div>
        </div>
        <div id="child-left">
        <img style="max-width: 100px; max-height: 100px;" src="https://cdn.discordapp.com/attachments/1047757132294000691/1163177331905532096/Ujung_kiri.png?ex=653ea04e&is=652c2b4e&hm=9cba56c016453abd6757943cfae45e3c9783daa96bd1a91e254f648393731fa2&" alt="" srcset="">
        </div>
        <div id="wave">
        <img style="max-width: 100px; max-height: 100px;"
            src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765837485228142/VIP_Kanan_Bawah.svg?ex=653d2112&is=652aac12&hm=0445d8602551a49fe48637859baa75e73491f4d456473d61fc3eea6b576119cd&" alt=""
            srcset="">
        </div>
    </div>
    `);
  } else if (role == "broadcast") {
    element = $.parseHTML(`
    <div data-sender="${uid}" data-msgid="${msgId}" id="section">
        
        <div id="ear">
                <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765839066484776/Streamer_Head.svg?ex=65465b93&is=6533e693&hm=0125742e704f99438acd7e7bbe0702d6debf8549246fc5df447a22a2a8fa4b10&" alt="">
        </div>
        <div id="username" class="username-broadcast">
        <div id="logo">
        <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1166375219934543913/STREAMER.png?ex=654a4292&is=6537cd92&hm=561cb984a2fc56a298c53ae204e15087a105e7bd3495fa785faa902f493af89c&" alt="">
        </div>
            <div id="name" class="broadcast-name">${username}</div>
           
            </div>
        <div id="container">
        <div id="crab">
        <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765838634467489/Streamer_Chat_atas_kanan.svg?ex=653d2113&is=652aac13&hm=59b0fa43f50a473440d8b646b641a01f7c64fb5c29c17b03f133a2c9b924991f&" alt=""
            srcset="">
        </div>
        <div id="bintang-kiri">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765837837553684/Star_chat.svg?ex=653d2112&is=652aac12&hm=ad048aa3ad02fce65945f4599c92f586e014696d23c8cd1cabe9b4ac253a2d43&" alt="">
        </div>
        <div id="rotator" class="broadcast">
            
            <div id="text">
            ${message}
            </div>
        </div>
        <div id="bintang-kanan">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1163155306851864696/Asset_1.png?ex=653e8bcb&is=652c16cb&hm=016b92b9dd406679a42a757ccf1d677720c5d4c8a8e62b3c3c3157c3dc447d2a&" alt="">
        </div>
        </div>
        <div id="child-left">
        <img style="max-width: 100px; max-height: 100px;" src="https://cdn.discordapp.com/attachments/1047757132294000691/1163177331905532096/Ujung_kiri.png?ex=653ea04e&is=652c2b4e&hm=9cba56c016453abd6757943cfae45e3c9783daa96bd1a91e254f648393731fa2&" alt="" srcset="">
        </div>
        <div id="wave">
        <img style="max-width: 100px; max-height: 100px;"
            src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765839414603908/Streamer_Kanan_Bawah.svg?ex=653d2113&is=652aac13&hm=c1ae7160310b579efa5d7bfd0966c3e5baad40e891292c7ecc0d12f1e08ada78&" alt=""
            srcset="">
        </div>
    </div>
    `);
  } else if (role == "mod") {
    element = $.parseHTML(`
    <div data-sender="${uid}" data-msgid="${msgId}" id="section">
        
        <div id="ear">
                <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765823186829473/Mod_Head.svg" alt="">
        </div>
        <div id="username" class="username-mod">
        <div id="logo">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1166375218298761276/MOD.png?ex=654a4292&is=6537cd92&hm=81877f37e0dd08ae80d37839e3e9e9f2b2a11d3502c6e91c06e5b62e8cce19f0&" alt="">
            </div>
            <div id="name" class="moderator-name">${username}</div>
            
            </div>
        <div id="container">
        <div id="crab">
        <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765823866306600/Moderator_Chat_atas_kanan.svg?ex=653d210f&is=652aac0f&hm=ac4086757eae7df7034f2253839969b9b03c226def6d7d4eb01f0b1f832c875a&" alt=""
            srcset="">
        </div>
        <div id="bintang-kiri">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765837837553684/Star_chat.svg?ex=653d2112&is=652aac12&hm=ad048aa3ad02fce65945f4599c92f586e014696d23c8cd1cabe9b4ac253a2d43&" alt="">
        </div>
        <div id="rotator" class="moderator">
            
            <div id="text">
            ${message}
            </div>
        </div>
        <div id="bintang-kanan">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1163155306851864696/Asset_1.png?ex=653e8bcb&is=652c16cb&hm=016b92b9dd406679a42a757ccf1d677720c5d4c8a8e62b3c3c3157c3dc447d2a&" alt="">
        </div>
        </div>
        <div id="child-left">
        <img style="max-width: 100px; max-height: 100px;" src="https://cdn.discordapp.com/attachments/1047757132294000691/1163177331905532096/Ujung_kiri.png?ex=653ea04e&is=652c2b4e&hm=9cba56c016453abd6757943cfae45e3c9783daa96bd1a91e254f648393731fa2&" alt="" srcset="">
        </div>
        <div id="wave">
        <img style="max-width: 100px; max-height: 100px;"
            src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765823539167342/Mod_Kanan_Bawah.svg?ex=653d210f&is=652aac0f&hm=31eba833da3811d998f0c0f374605a84ecc2cdc2ec56b324436746967d3fa7e9&" alt=""
            srcset="">
        </div>
    </div>
    `);
  }  else if (role == "artist") {
    element = $.parseHTML(`
    <div data-sender="${uid}" data-msgid="${msgId}" id="section">
        
        <div id="ear">
                <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765822398316624/Member_Head.svg" alt="">
        </div>
        <div id="username" class="username-artist">
        <div id="logo">
          <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1166375222547595264/ARTIST.png?ex=654a4293&is=6537cd93&hm=8d37bb449dfbe1ae6a1dbd94c1d0a2897f131c75727d78ca3ab86cb4148407bf&" alt="">
        </div>
        <div id="name" class="artist-name">${username}</div>
        
        </div>
        <div id="container">
        <div id="crab">
        <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765822045990912/member_Chat_atas_kanan.svg?ex=653d210f&is=652aac0f&hm=494b421ac9fcf1dbfe8a0a463ac8e8a5a1365f8be06504cdf2674529dcd23f87&" alt=""
            srcset="">
        </div>
        <div id="bintang-kiri">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765837837553684/Star_chat.svg?ex=653d2112&is=652aac12&hm=ad048aa3ad02fce65945f4599c92f586e014696d23c8cd1cabe9b4ac253a2d43&" alt="">
        </div>
        <div id="rotator" class="artist">
           
            <div id="text">
            ${message}
            </div>
        </div>
        <div id="bintang-kanan">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1163155306851864696/Asset_1.png?ex=653e8bcb&is=652c16cb&hm=016b92b9dd406679a42a757ccf1d677720c5d4c8a8e62b3c3c3157c3dc447d2a&" alt="">
        </div>
        </div>
        <div id="child-left">
        <img style="max-width: 100px; max-height: 100px;" src="https://cdn.discordapp.com/attachments/1047757132294000691/1163177331905532096/Ujung_kiri.png?ex=653ea04e&is=652c2b4e&hm=9cba56c016453abd6757943cfae45e3c9783daa96bd1a91e254f648393731fa2&" alt="" srcset="">
        </div>
        <div id="wave">
        <img style="max-width: 100px; max-height: 100px;"
            src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765822742245417/Member_Kanan_Bawah.svg?ex=653d210f&is=652aac0f&hm=bbc54dfa9f206aab3a8a2ebbb67b2ef01813583f5d617a16396b4b6900f21331&" alt=""
            srcset="">
        </div>
    </div>
    `);
  } else if (role == "subs") {
    element = $.parseHTML(`
    <div data-sender="${uid}" data-msgid="${msgId}" id="section">
       
        <div id="ear">
                <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765822398316624/Member_Head.svg" alt="">
        </div>
        <div id="username" class="username-subs">
        <div id="logo">
        <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1166375220802760774/SUB.png?ex=654a4292&is=6537cd92&hm=cb6f4da48765be7c88dee25f61d4b3e522abdf7f31ec22f5e4fac2bcfb931e65&" alt="">
      </div>
            <div id="name" class="subs-name">${username}</div>
           
            </div>
        <div id="container">
        <div id="crab">
        <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765822045990912/member_Chat_atas_kanan.svg?ex=653d210f&is=652aac0f&hm=494b421ac9fcf1dbfe8a0a463ac8e8a5a1365f8be06504cdf2674529dcd23f87&" alt=""
            srcset="">
        </div>
        <div id="bintang-kiri">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765837837553684/Star_chat.svg?ex=653d2112&is=652aac12&hm=ad048aa3ad02fce65945f4599c92f586e014696d23c8cd1cabe9b4ac253a2d43&" alt="">
        </div>
        <div id="rotator" class="subs">
            
            <div id="text">
            ${message}
            </div>
        </div>
        <div id="bintang-kanan">
            <img src="https://cdn.discordapp.com/attachments/1047757132294000691/1163155306851864696/Asset_1.png?ex=653e8bcb&is=652c16cb&hm=016b92b9dd406679a42a757ccf1d677720c5d4c8a8e62b3c3c3157c3dc447d2a&" alt="">
        </div>
        </div>
        <div id="child-left">
        <img style="max-width: 100px; max-height: 100px;" src="https://cdn.discordapp.com/attachments/1047757132294000691/1163177331905532096/Ujung_kiri.png?ex=653ea04e&is=652c2b4e&hm=9cba56c016453abd6757943cfae45e3c9783daa96bd1a91e254f648393731fa2&" alt="" srcset="">
        </div>
        <div id="wave">
        <img style="max-width: 100px; max-height: 100px;"
            src="https://cdn.discordapp.com/attachments/1047757132294000691/1162765822742245417/Member_Kanan_Bawah.svg?ex=653d210f&is=652aac0f&hm=bbc54dfa9f206aab3a8a2ebbb67b2ef01813583f5d617a16396b4b6900f21331&" alt=""
            srcset="">
        </div>
    </div>
    `);
  }

  console.log(element);

  if (addition === "append") {
    if (hideAfter !== 999) {
      $(element)
        .appendTo(".main-container")
        .delay(hideAfter * 1000)
        .queue(function () {
          $(this)
            .removeClass(animationIn)
            .addClass(animationOut)
            .delay(1000)
            .queue(function () {
              $(this).remove();
            })
            .dequeue();
        });
    } else {
      $(element).appendTo(".main-container");
    }
  } else {
    if (hideAfter !== 999) {
      $(element)
        .appendTo(".main-container")
        .delay(hideAfter * 1000)
        .queue(function () {
          $(this)
            .removeClass(animationIn)
            .addClass(animationOut)
            .delay(1000)
            .queue(function () {
              $(this).remove();
            })
            .dequeue();
        });
    } else {
      $(element).appendTo(".main-container");
    }
  }

  if (totalMessages > messagesLimit) {
    removeRow();
  }
}

function removeRow() {
  if (!$(removeSelector).length) {
    return;
  }
  if (animationOut !== "none" || !$(removeSelector).hasClass(animationOut)) {
    if (hideAfter !== 999) {
      $(removeSelector).dequeue();
    } else {
      $(removeSelector)
        .addClass(animationOut)
        .delay(1000)
        .queue(function () {
          $(this).remove().dequeue();
        });
    }
    return;
  }

  $(removeSelector).animate(
    {
      height: 0,
      opacity: 0,
    },
    "slow",
    function () {
      $(removeSelector).remove();
    }
  );
}